package com.example.b2013486_ntkn_uocmo.models

data class RequestRegisterOrLogin(
    val username: String
)