package com.example.b2013486_ntkn_uocmo.models

data class UserResponse(
    val success: Boolean,
    val message: String,
    val idUser: String?
)