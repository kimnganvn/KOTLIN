package com.example.b2013486_ntkn_uocmo.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.b2013486_ntkn_uocmo.R
import com.example.b2013486_ntkn_uocmo.apis.Constants
import com.example.b2013486_ntkn_uocmo.databinding.FragmentUpdateBinding
import com.example.b2013486_ntkn_uocmo.models.RequestUpdateWish
import com.example.b2013486_ntkn_uocmo.sharedpreferences.AppSharedPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class UpdateFragment : Fragment() {
    private lateinit var binding: FragmentUpdateBinding
    private lateinit var mAppSharedPreferences: AppSharedPreferences
    private var idUser = ""
    private var idWish = ""
    private var fullName = ""
    private var content = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentUpdateBinding.inflate(layoutInflater, container, false)

        /**Khởi tạo mAppSharePreferences và láy idUser, wish từ mAppSharePreferences*/
        mAppSharedPreferences = AppSharedPreferences(requireContext())
        idUser = mAppSharedPreferences.getIdUser("idUser").toString()
        idWish = mAppSharedPreferences.getWish("idWish").toString()
        fullName = mAppSharedPreferences.getWish("fullName").toString()
        content = mAppSharedPreferences.getWish("content").toString()

        /** Thiết lập nội dung lên giao diện*/
        binding.edtFullName.setText(fullName)
        binding.edtContent.setText(content)

        binding.apply {
            btnSave.setOnClickListener {
                if (edtFullName.text.isNotEmpty() && edtContent.text.isNotEmpty()) {
                    fullName = edtFullName.text.toString().trim()
                    content = edtContent.text.toString().trim()
                    /** Thực hiện call api thêm điều ước */
                    updateWish(fullName, content)
                }
            }
        }

        return binding.root
    }
    private fun updateWish(fullName : String, content: String){
        binding.progressBar.visibility = View.VISIBLE
        CoroutineScope(Dispatchers.IO).launch {
            withContext(Dispatchers.Main){
                val response = Constants.getInstance()
                    .updateWish(RequestUpdateWish(idUser,idWish,fullName,content))
                    .body()

                if (response!=null){
                    if (response.success){
                        binding.progressBar.visibility = View.GONE
                        /** Cập nhật điều ước thành công */
                        Toast.makeText(requireContext(),response.message, Toast.LENGTH_SHORT).show()
                        requireActivity().supportFragmentManager.beginTransaction()
                            .replace(R.id.frame_layout,WishListFragment())
                            .commit()
                    }else{
                        binding.progressBar.visibility = View.GONE
                        /**Cập nhật điều ước không thành công */
                        Toast.makeText(requireContext(),response.message,Toast.LENGTH_SHORT).show()
                        requireActivity().supportFragmentManager.beginTransaction()
                            .replace(R.id.frame_layout, LoginFragment())
                            .commit()
                    }
                }
            }
        }
    }
}