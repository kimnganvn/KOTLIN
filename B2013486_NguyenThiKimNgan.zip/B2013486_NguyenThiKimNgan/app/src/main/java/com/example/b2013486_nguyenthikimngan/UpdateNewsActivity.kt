package com.example.b2013486_nguyenthikimngan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class UpdateNewsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_news)
    }
}