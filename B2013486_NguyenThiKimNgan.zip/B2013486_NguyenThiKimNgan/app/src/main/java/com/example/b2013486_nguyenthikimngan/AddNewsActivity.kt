package com.example.b2013486_nguyenthikimngan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AddNewsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_news)
    }
}