package com.example.mymap.models

object Utils {
    const val EXTRA_USER_MAP = "EXTRA_USER_MAP"
    const val EXTRA_MAP_TITLE = "EXTRA_MAP_TITLE"
}