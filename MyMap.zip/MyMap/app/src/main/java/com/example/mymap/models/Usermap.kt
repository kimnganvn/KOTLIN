package com.example.mymap.models

import java.io.Serializable

data class Usermap(
    val title: String,
    val places: List<Place>
):Serializable
