package com.example.b2013486

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.mariuszgromada.math.mxparser.Expression



class MainActivity : AppCompatActivity() {
    var lastNumeric: Boolean = false
    var lastDot: Boolean = false
    var lastOperator: Boolean = false

    private var tvInput: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Thiết lập layout cho Activity
        tvInput = findViewById(R.id.tvInput) // Gán TextView từ layout
    }

    //Hàm xử lý khi một số được nhấn
    fun onDigit(view: View) {
        if (view is TextView) { //kiểm tra view có phải là thực thể kểu TextView hay không
            val digit = view.text.toString()
            val currentText = tvInput?.text.toString()
            tvInput?.text = currentText + digit
            lastNumeric = true
        }
    }

    //Xử lý sự kiện khi nhấn nút Clear để xoá nội dung
    fun onClear(view: View) {
        tvInput?.text = ""
        lastNumeric = false
        lastDot = false
    }

    //Hàm xử lý sự kiện khi nhấn dấu thập phân
    fun onDecimalPoint(view: View) {
        if (lastNumeric && !lastDot) {
            val currentText = tvInput?.text.toString()
            tvInput?.text = currentText + "."
            lastNumeric = false
            lastDot = true
        }
    }

    //Xử lý khi nhấn toán tử
    fun onOperator(view: View) {
        if (lastNumeric && !isOperatorAdded(tvInput?.text.toString())) {
            val operator = (view as TextView).text.toString()
            val currentText = tvInput?.text.toString()
            tvInput?.text = currentText + operator
            lastNumeric = false
            lastDot = false
        }
    }

    //Xử lý khi nhấn nút =
    fun onEqual(view: View) {
        var express = Expression(tvInput?.text.toString())
        var result = express.calculate()
        if (result.isNaN()) {
            tvInput?.text = "ERROR" //hiển thị lỗi
        }
        else {
            tvInput?.text = result.toString()
        }
    }

    //Loại bỏ số 0 sau dấu thập phân
    private fun removeZeroAfterDot(result: String): String {

        if (result.endsWith(".0")) {
            return result.substring(0,result.length-2)
        }
        return result
    }

    //Kiểm tra một phép toán được thêm vào biểu thức chưa
    private fun isOperatorAdded(value: String): Boolean {
        return if (value.startsWith("-")) { //kiểm tra xem có bắt đầu bằng dấu trừ hay không
            false
        } else {
            //kiểm tra biểu thức có chứa phép toán nào hay không
            value.contains("+") || value.contains("-") || value.contains("*") || value.contains("/")
        }
    }

}


